sap.ui.define([
	"secondproject/Z_secondProject/test/unit/controller/View1.controller"
], function () {
	"use strict";
});